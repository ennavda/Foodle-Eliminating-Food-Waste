package com.swe.foodle;

/**
 * The meal categories types Foodle displays recipes for.
 */
public enum MealCategoryType {
    Breakfast, Lunch, Dinner, Dessert
}
