package com.swe.foodle;

import android.app.ActionBar;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.design.widget.NavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Switch;
import android.widget.TableLayout;
import android.widget.Toast;
import android.widget.Toolbar;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MyFridge extends AppCompatActivity {

    ArrayList<String> expiringIngredients = new ArrayList<>();
    // stores the ingredient list used to populate the side bar menu when using ingredient search
    private List<Ingredient> ingredientsList = new ArrayList<>();

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // R.menu.mymenu is a reference to an xml file named mymenu.xml which should be inside your res/menu directory.
        // If you don't have res/menu, just create a directory named "menu" inside res
        getMenuInflater().inflate(R.menu.actionbar_button, menu);
        return super.onCreateOptionsMenu(menu);
    }

   @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_fridge);
        getSupportActionBar().setHomeButtonEnabled(true);

       final ListView list = findViewById(R.id.list);
       expiringIngredients.add("Chicken - 2/9/2020");
       expiringIngredients.add("Tomato - 2/25/2020");
       expiringIngredients.add("Cheese - 2/28/2020");
       expiringIngredients.add("Spinach - 3/1/2020");
       expiringIngredients.add("Chicken Stock - 12/25/2020");

       ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, expiringIngredients);
       list.setAdapter(arrayAdapter);

       setUpEndWorldHungerButton();
    }

    /**
     * Sets up the button to add ingredients to the list in navigation menu
     */
    private void setUpEndWorldHungerButton() {
        Button ewh = findViewById(R.id.endWorldHunger);
        ewh.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                for (int i = 0; i < 3; i++) {
                    intent.putExtra(String.valueOf(i), expiringIngredients.get(i));
                }
                startActivity(intent);
            }
        });
    }
}
